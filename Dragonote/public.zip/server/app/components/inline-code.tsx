import { o } from '../jsx/jsx.js'

export function code(html: string) {
  return <code class="inline-code">{html}</code>
}

export default code
