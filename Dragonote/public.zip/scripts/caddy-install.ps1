curl.exe https://webi.ms/caddy | powershell
