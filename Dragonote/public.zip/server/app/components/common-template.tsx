export let commonTemplatePageText =
  'This page serve as template of common use case.'
