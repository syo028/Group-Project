import { o } from '../jsx/jsx.js'

export let ionicStyle = (
  <>
    <script
      type="module"
      src="/npm/@ionic/core/dist/ionic/ionic.esm.js"
    ></script>
    <script nomodule src="/npm/@ionic/core/dist/ionic/ionic.js"></script>
    <link rel="stylesheet" href="/npm/@ionic/core/css/ionic.bundle.css" />
  </>
)
