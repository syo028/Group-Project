export let FormStyle = /* css */ `
form .input-container {
  margin-top: 0.25rem;
  /* margin-bottom: 0.75rem; */
}

.separator-line::before,
.separator-line::after {
  content: '';
  flex: 1;
  border-bottom: 1px solid #888;
  margin: 1rem 0.75rem;
}
`
