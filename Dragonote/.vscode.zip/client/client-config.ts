export let client_config = {
  max_image_size: 300 * 1000,
  toast_duration: 3800,
}
