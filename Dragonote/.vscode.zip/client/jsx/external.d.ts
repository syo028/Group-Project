declare namespace JSX {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  type Element = any
  interface IntrinsicElements {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [elemName: string]: any
  }
}
