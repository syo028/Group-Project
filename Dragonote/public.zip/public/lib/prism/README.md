The 3rd party library code `prism.css` and `prism.js` are ignored from git but required for the `<SourceCode>` component.

## Download Link

https://prismjs.com/download.html#themes=prism-tomorrow&languages=markup+css+clike+javascript+bash+markdown+jsx+tsx+typescript

## Configuration

### Theme

- Tomorrow Night by Rosey (1.28KB)

### Languages

- React TSX (0.3KB)
- CSS (1.71KB)
- Bash + Shell by zeitgeist87 (8.7KB)
- Markdown by Golmote (5.02KB)
