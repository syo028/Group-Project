/* to hint the html streaming flow to flush the compression stream */
export function Flush() {
  return null
}
